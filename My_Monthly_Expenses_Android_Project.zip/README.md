# My Monthly Expenses (Android starter project)

## Features in this starter
- English interface and INR currency
- Add income and expenses
- Choose categories and add an optional note
- View balance, income, expenses, and transaction history
- Saves transactions locally on the device

## Open and build
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install the Android SDK requested by the project.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

This is the source project, not a prebuilt APK. The CSV file supplied in the chat has column headers but no transaction rows, so there are no past transactions to import.
