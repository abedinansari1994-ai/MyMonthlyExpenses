package com.example.mymonthlyexpenses

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Entry(val type: String, val amount: Double, val category: String, val date: String, val note: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { ExpenseApp() } }
    }
}

@Composable
fun ExpenseApp() {
    val context = LocalContext.current
    val entries = remember { mutableStateListOf<Entry>().apply { addAll(loadEntries(context)) } }
    var type by remember { mutableStateOf("Expense") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Food") }
    var note by remember { mutableStateOf("") }
    val income = entries.filter { it.type == "Income" }.sumOf { it.amount }
    val expenses = entries.filter { it.type == "Expense" }.sumOf { it.amount }
    val balance = income - expenses

    fun addEntry() {
        val value = amount.toDoubleOrNull() ?: return
        if (value <= 0) return
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        entries.add(0, Entry(type, value, category, date, note))
        saveEntries(context, entries)
        amount = ""; note = ""
    }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("My Monthly Expenses", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Track your income and spending", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Current Balance", style = MaterialTheme.typography.titleMedium)
                        Text("₹${"%.2f".format(balance)}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Income  ₹${"%.2f".format(income)}", color = MaterialTheme.colorScheme.primary)
                            Text("Expenses  ₹${"%.2f".format(expenses)}", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
            item {
                Text("Add transaction", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = type == "Expense", onClick = { type = "Expense" }, label = { Text("Expense") })
                    FilterChip(selected = type == "Income", onClick = { type = "Income" }, label = { Text("Income") })
                }
                OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("Amount (₹)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                var expanded by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { expanded = true }) { Text("Category: $category") }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        (if (type == "Expense") listOf("Food","Travel","Shopping","Bills","Health","Education","Rent","Other") else listOf("Salary","Business","Interest","Gift","Other")).forEach {
                            DropdownMenuItem(text = { Text(it) }, onClick = { category = it; expanded = false })
                        }
                    }
                }
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note (optional)") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { addEntry() }, modifier = Modifier.fillMaxWidth(), enabled = amount.toDoubleOrNull()?.let { it > 0 } == true) { Text("Save transaction") }
            }
            item { Text("Transaction history", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold) }
            if (entries.isEmpty()) item { Text("No transactions yet. Add your first income or expense above.") }
            items(entries) { e ->
                Card {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("${e.category} • ${e.type}", fontWeight = FontWeight.SemiBold)
                            Text("${e.date}${if (e.note.isNotBlank()) " • ${e.note}" else ""}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text((if (e.type == "Income") "+" else "-") + "₹${"%.2f".format(e.amount)}",
                            color = if (e.type == "Income") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun loadEntries(context: Context): List<Entry> {
    val raw = context.getSharedPreferences("expenses", Context.MODE_PRIVATE).getString("entries", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Entry(o.getString("type"), o.getDouble("amount"), o.getString("category"), o.getString("date"), o.optString("note"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveEntries(context: Context, entries: List<Entry>) {
    val arr = JSONArray()
    entries.forEach { e ->
        arr.put(JSONObject().put("type", e.type).put("amount", e.amount).put("category", e.category).put("date", e.date).put("note", e.note))
    }
    context.getSharedPreferences("expenses", Context.MODE_PRIVATE).edit().putString("entries", arr.toString()).apply()
}
